import { useDb } from '../db/client'

export interface ExecutionRecord {
  id: number
  test_case_id: number
  release_id: number
  result: 'Pass' | 'Fail' | 'Blocked' | 'Not Run'
  executed_by: number
  execution_date: string
  actual_result: string | null
  test_case_title_snapshot: string | null
  steps_snapshot: string | null
  expected_result_snapshot: string | null
}

export interface TestCaseExecutionState {
  id: number
  title: string
  module_id: number
  module_name: string
  steps: string | null
  expected_result: string | null
  priority: 'High' | 'Medium' | 'Low' | null
  type: string
  latest_result: string | null
  last_executed_at: string | null
  last_executed_by_email: string | null
  latest_actual_result: string | null
  executions_count: number
}

export const executionRepository = {
  // Returns every test case ASSIGNED TO THIS RELEASE (via
  // test_case_release_links) with its latest execution state for that
  // release. A test case not linked to this release never appears here,
  // even if it has been executed under a different release in the past.
  // Archived (soft-deleted) test cases are excluded too, so nobody can
  // log a fresh execution against something that's been taken out of
  // active use -- past executions logged before it was archived still
  // count toward its history, this just stops new ones.
  // Null latest_result means "not yet run in this release".
  async getReleaseState(releaseId: number): Promise<TestCaseExecutionState[]> {
    const sql = useDb()
    const rows = await sql`
      with latest as (
        select distinct on (test_case_id)
          test_case_id, result, execution_date, actual_result, executed_by
        from test_executions
        where release_id = ${releaseId}
        order by test_case_id, execution_date desc
      ),
      counts as (
        select test_case_id, count(*)::int as cnt
        from test_executions
        where release_id = ${releaseId}
        group by test_case_id
      )
      select
        tc.id,
        tc.title,
        tc.module_id,
        tc.steps,
        tc.expected_result,
        tc.priority,
        tc.type,
        m.name as module_name,
        l.result as latest_result,
        l.execution_date as last_executed_at,
        l.actual_result as latest_actual_result,
        u.email as last_executed_by_email,
        coalesce(c.cnt, 0) as executions_count
      from test_case_release_links trl
      join test_cases tc on tc.id = trl.test_case_id and tc.archived = false
      join modules m on m.id = tc.module_id
      left join latest l on l.test_case_id = tc.id
      left join counts c on c.test_case_id = tc.id
      left join users u on u.id = l.executed_by
      where trl.release_id = ${releaseId}
      order by m.name asc, tc.title asc
    `
    return rows as TestCaseExecutionState[]
  },

  // Append-only insert. The DB trigger prevent_execution_modify blocks any
  // UPDATE or DELETE on this table, so this is genuinely the only way to
  // add execution history. The snapshot fields capture the test case's
  // steps/expected result/title exactly as they were at this moment, so a
  // later edit to the test case never rewrites what this run recorded
  // against.
  async create(input: {
    testCaseId: number
    releaseId: number
    result: 'Pass' | 'Fail' | 'Blocked' | 'Not Run'
    actualResult: string | null
    executedBy: number
    testCaseTitleSnapshot: string
    stepsSnapshot: string | null
    expectedResultSnapshot: string | null
  }): Promise<ExecutionRecord> {
    const sql = useDb()
    const rows = await sql`
      insert into test_executions (
        test_case_id, release_id, result, actual_result, executed_by,
        test_case_title_snapshot, steps_snapshot, expected_result_snapshot
      )
      values (
        ${input.testCaseId}, ${input.releaseId}, ${input.result}, ${input.actualResult}, ${input.executedBy},
        ${input.testCaseTitleSnapshot}, ${input.stepsSnapshot}, ${input.expectedResultSnapshot}
      )
      returning *
    `
    return rows[0] as ExecutionRecord
  }
}
